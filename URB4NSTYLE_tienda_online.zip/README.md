# URB4NSTYLE — proyecto inicial de tienda online

Este proyecto es una base funcional en Flask con base de datos SQLite, catálogo, carrito, pedidos, panel `/admin` y salida a WhatsApp.

## Importante antes de publicarla
Esta carpeta NO está publicada en Internet todavía. Para ponerla online hace falta una cuenta de alojamiento que soporte Python/Flask y almacenamiento persistente. Pide ayuda a un adulto para crear y gestionar las cuentas.

La versión incluida es una base inicial, no una tienda lista para aceptar ventas reales sin revisión técnica. Antes de usarla comercialmente:
- Configurar `SECRET_KEY` con un valor aleatorio largo.
- Configurar `ADMIN_PASSWORD_HASH` con un hash de contraseña generado con Werkzeug.
- Desactivar el modo debug en producción y activar HTTPS.
- Configurar copias de seguridad y almacenamiento persistente.
- Revisar seguridad, privacidad, protección de datos, condiciones de compra, devoluciones y obligaciones legales.
- Probar el flujo de pedidos y stock. El pedido se registra cuando el cliente pulsa el botón de pedido; confirma por WhatsApp antes de preparar el envío.
- La gestión de tallas y stock es básica: el stock se controla a nivel de producto, no por talla.
- La imagen de portada es una composición gráfica hecha con CSS; puedes sustituirla por una foto de campaña propia que tengas derecho a usar.

## Ejecutar localmente para probar
Necesitas Python 3.10+:
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
```
En PowerShell:
```powershell
$env:SECRET_KEY="pon-un-secreto-largo-y-aleatorio"
$env:ADMIN_PASSWORD_HASH="PEGA_AQUI_EL_HASH"
$env:WHATSAPP_NUMBER="34622958784"
python app.py
```
Genera un hash de contraseña desde una terminal con:
```bash
python -c "from werkzeug.security import generate_password_hash; print(generate_password_hash('TU-CONTRASEÑA-LARGA'))"
```
No uses literalmente la contraseña del ejemplo; crea una contraseña única y no la compartas por chat.
Después abre `http://127.0.0.1:5000`. La tienda usa `http://127.0.0.1:5000/admin` para administración.

## Categorías
Chándales, sudaderas, camisetas, pantalones, gorras y zapatillas.

## Configuración inicial
- WhatsApp: número configurado a partir del dato proporcionado por el usuario.
- Envío: 4,99 € (editable desde ajustes del panel).
- Los productos se añaden desde el panel.
