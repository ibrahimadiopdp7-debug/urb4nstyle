import os, sqlite3, json
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify, abort
from werkzeug.security import check_password_hash, generate_password_hash
from werkzeug.utils import secure_filename

APP_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(APP_DIR, "urb4nstyle.db")
UPLOAD_DIR = os.path.join(APP_DIR, "static", "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "CHANGE_THIS_BEFORE_PUBLISHING")
app.config["MAX_CONTENT_LENGTH"] = 8 * 1024 * 1024
app.config["UPLOAD_FOLDER"] = UPLOAD_DIR
ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "webp"}

WHATSAPP_NUMBER = os.environ.get("WHATSAPP_NUMBER", "34622958784")

app.jinja_env.filters['from_json'] = lambda value: json.loads(value or '[]')

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with db() as con:
        con.execute("""CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL, category TEXT NOT NULL, price REAL NOT NULL,
            sizes TEXT NOT NULL DEFAULT '[]', stock INTEGER NOT NULL DEFAULT 0,
            image TEXT NOT NULL DEFAULT '', description TEXT NOT NULL DEFAULT '',
            active INTEGER NOT NULL DEFAULT 1
        )""")
        con.execute("""CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            items TEXT NOT NULL, total REAL NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            status TEXT NOT NULL DEFAULT 'Nuevo'
        )""")
        con.execute("""CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY, value TEXT NOT NULL
        )""")
        con.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('shipping','4.99')")
        con.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('store_name','URB4NSTYLE')")

def setting(key, default=""):
    with db() as con:
        row = con.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        return row["value"] if row else default

def admin_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        if not session.get("admin"):
            return redirect(url_for("admin_login"))
        return fn(*args, **kwargs)
    return wrapped

def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS

@app.context_processor
def inject_globals():
    return {"shipping_price": float(setting("shipping", "4.99")), "whatsapp_number": WHATSAPP_NUMBER}

@app.route("/")
def home():
    category = request.args.get("category", "")
    search = request.args.get("q", "").strip()
    sql = "SELECT * FROM products WHERE active=1"
    params = []
    if category:
        sql += " AND category=?"
        params.append(category)
    if search:
        sql += " AND (name LIKE ? OR description LIKE ?)"
        params.extend([f"%{search}%", f"%{search}%"])
    sql += " ORDER BY id DESC"
    with db() as con:
        products = con.execute(sql, params).fetchall()
    categories = ["Chándales", "Sudaderas", "Camisetas", "Pantalones", "Gorras", "Zapatillas"]
    return render_template("home.html", products=products, categories=categories, selected_category=category, search=search)

@app.route("/order", methods=["POST"])
def order():
    try:
        items = json.loads(request.form.get("items", "[]"))
    except json.JSONDecodeError:
        items = []
    if not isinstance(items, list) or not items:
        flash("Tu carrito está vacío.")
        return redirect(url_for("home"))
    safe_items = []
    subtotal = 0.0
    with db() as con:
        for item in items:
            try:
                pid = int(item.get("id"))
                qty = max(1, min(20, int(item.get("qty", 1))))
            except (TypeError, ValueError):
                continue
            product = con.execute("SELECT * FROM products WHERE id=? AND active=1", (pid,)).fetchone()
            if not product or product["stock"] < qty:
                continue
            price = float(product["price"])
            safe_items.append({"id": pid, "name": product["name"], "size": str(item.get("size","")), "qty": qty, "price": price})
            subtotal += price * qty
        if not safe_items:
            flash("No hay productos disponibles en las cantidades elegidas.")
            return redirect(url_for("home"))
        total = round(subtotal + float(setting("shipping", "4.99")), 2)
        con.execute("INSERT INTO orders(items,total) VALUES(?,?)", (json.dumps(safe_items, ensure_ascii=False), total))
        for item in safe_items:
            con.execute("UPDATE products SET stock=MAX(0, stock-?) WHERE id=?", (item["qty"], item["id"]))
    lines = ["Hola, quiero hacer este pedido en URB4NSTYLE:"]
    for item in safe_items:
        size_text = f" (talla {item['size']})" if item["size"] else ""
        lines.append(f"- {item['name']}{size_text} x{item['qty']} — {item['price']:.2f} €")
    lines.append(f"Envío: {float(setting('shipping','4.99')):.2f} €")
    lines.append(f"Total: {total:.2f} €")
    from urllib.parse import quote
    return redirect("https://wa.me/" + WHATSAPP_NUMBER + "?text=" + quote("\n".join(lines)))

@app.route("/admin")
def admin_root():
    return redirect(url_for("admin_dashboard"))

@app.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    if request.method == "POST":
        expected = os.environ.get("ADMIN_PASSWORD_HASH", "")
        password = request.form.get("password", "")
        if expected and check_password_hash(expected, password):
            session["admin"] = True
            return redirect(url_for("admin_dashboard"))
        flash("Acceso no válido. Configura ADMIN_PASSWORD_HASH en el servidor.")
    return render_template("login.html")

@app.route("/admin/logout")
def admin_logout():
    session.clear()
    return redirect(url_for("home"))

@app.route("/admin/dashboard")
@admin_required
def admin_dashboard():
    with db() as con:
        products = con.execute("SELECT * FROM products ORDER BY id DESC").fetchall()
        orders = con.execute("SELECT * FROM orders ORDER BY id DESC LIMIT 100").fetchall()
    return render_template("admin.html", products=products, orders=orders, store_name=setting("store_name","URB4NSTYLE"))

@app.route("/admin/products", methods=["POST"])
@admin_required
def add_product():
    name = request.form.get("name","").strip()
    category = request.form.get("category","").strip()
    try:
        price = float(request.form.get("price","0"))
        stock = max(0, int(request.form.get("stock","0")))
    except ValueError:
        flash("Precio o stock no válido.")
        return redirect(url_for("admin_dashboard"))
    sizes = [s.strip() for s in request.form.get("sizes","").split(",") if s.strip()]
    description = request.form.get("description","").strip()
    image_path = ""
    image = request.files.get("image")
    if image and image.filename and allowed_file(image.filename):
        filename = secure_filename(image.filename)
        filename = str(os.urandom(5).hex()) + "_" + filename
        image.save(os.path.join(UPLOAD_DIR, filename))
        image_path = "/static/uploads/" + filename
    if not name or not category or price < 0:
        flash("Completa el nombre, categoría y precio.")
        return redirect(url_for("admin_dashboard"))
    with db() as con:
        con.execute("INSERT INTO products(name,category,price,sizes,stock,image,description) VALUES(?,?,?,?,?,?,?)",
                    (name, category, price, json.dumps(sizes, ensure_ascii=False), stock, image_path, description))
    flash("Producto añadido.")
    return redirect(url_for("admin_dashboard"))

@app.route("/admin/products/<int:pid>/delete", methods=["POST"])
@admin_required
def delete_product(pid):
    with db() as con:
        con.execute("UPDATE products SET active=0 WHERE id=?", (pid,))
    flash("Producto ocultado de la tienda.")
    return redirect(url_for("admin_dashboard"))

@app.route("/admin/settings", methods=["POST"])
@admin_required
def save_settings():
    try:
        shipping = float(request.form.get("shipping","4.99"))
        if shipping < 0: raise ValueError()
    except ValueError:
        flash("El envío debe ser un precio válido.")
        return redirect(url_for("admin_dashboard"))
    with db() as con:
        con.execute("INSERT OR REPLACE INTO settings(key,value) VALUES('shipping',?)", (str(round(shipping,2)),))
    flash("Ajustes guardados.")
    return redirect(url_for("admin_dashboard"))

init_db()

if __name__ == "__main__":
    app.run(debug=True)
